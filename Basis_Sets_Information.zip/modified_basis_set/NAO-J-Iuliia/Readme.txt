NAO-J-n basis sets are designed for accurate J-coupling
calculations. These are based on the NAO-VCC-nZ but with tighter
integration grids and additional Gaussian functions taken from the
uncontracted pcJ-n basis sets.

Recipe:

H  : All Jensen exponents above 10^3
B-F: All Jensen exponents above 10^4 
Al-Cl: All Jensen exponents above 10^4 
